<div class="container col-md-12" style="padding: 150px;">

	<h1 style="font-style: inherit;font-size: 70px;text-align: center;color: #294452"><b>Welcome To<br><span style="color: #8d2948"> TooT Dashboard</span></b></h1>
	
</div>