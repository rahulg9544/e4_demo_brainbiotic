<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        // Load the database library
        $this->load->database();
        
        $this->userTbl = '';
    }

    function getsingleprod($pid)
{
	 $squery="SELECT * FROM product LEFT JOIN category ON category_id=product_category LEFT JOIN subcategory ON subcategory_id = product_subcategory LEFT JOIN division ON division_id=product_division LEFT JOIN brand ON brand_id=product_brand WHERE product_priority=0 AND product_id='$pid'";

		$query = $this->db->query($squery);
		return $query->row();
}

    function getprodsubdetils_single($prod_sub)
    {
        $this->db->where('subcategory_id',$prod_sub);
        $query = $this->db->get('subcategory');
        return $query->row();
    }

    public function get_categories()
	{
		$this->db->from('category');
		// $this->db->order_by("cat_priority", "DESC");
	    $query = $this->db->get();

	    $return = array();

	    foreach ($query->result() as $category)
	    {
	        $return[$category->category_id] = $category;
	        $return[$category->category_id]->subs = $this->get_sub_categories($category->category_id);
	        
	         // Get the categories sub categories
	    }
	    
	    return $return;
	}

}