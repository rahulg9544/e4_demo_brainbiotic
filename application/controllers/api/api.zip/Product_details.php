<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library
//require APPPATH . '/libraries/REST_Controller.php';

class Product_details extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        // Load the user model

        $this->load->model('api/product_model','product_model');
    }
    
    public function productdetails_get()
	{

    $pid=base64_decode($this->input->get('pid'));

    $getsingleprod=$this->TootModel->getsingleprod($pid);
    
    $getprodsubdetils_single=array();
    
        if(!empty($getsingleprod))
        {
            $prod_sub = $getsingleprod->product_subcategory;
            $getprodsubdetils_single = $this->product_model->getprodsubdetils_single($prod_sub);
        
        }

		$result=array(
			'tabproducts'=>$this->product_model->get_categories(),
      'singleprod'=>$getsingleprod,
      'prod_subcat'=>$getprodsubdetils_single,
      'content' => 'product-details'
      );
      $this->response([
        'data' => $result
    ], REST_Controller::HTTP_OK);  
	}    


    

}