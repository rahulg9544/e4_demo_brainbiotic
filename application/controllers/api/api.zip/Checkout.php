<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library
//require APPPATH . '/libraries/REST_Controller.php';

class Checkout extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        // Load the user model
        $this->load->model('api/checkout_model','checkout_model');

    }
// checkoutpage	

	public function checkout_get()
	{

         if(isset($_SESSION['cusername']) || isset($_SESSION["cgustid"]))
           {
            
            if(isset($_SESSION['cusername']))
              {
                  $userid  = base64_decode($_SESSION['userid']);
              }
              else
              {
                       if(isset($_SESSION["cgustid"]))
                       {
                         $userid  = base64_decode($_SESSION['cgustid']);
                       }
              } 
     
          $coupon=base64_decode($this->input->get('cpn'));
          $couponcartamnt=base64_decode($this->input->get('crtamnt'));
    
    
          $getcartitems = $this->checkout_model->getcartitemsforcheck($userid);
    
          if($getcartitems->num_rows()==0)
          {
             
              
              $this->response(['message' => 'Your Cart is Empty.',
                'data' => $result
            ], REST_Controller::HTTP_OK);

         
          }
          else
          {
    
          $getuseraddrs=$this->checkout_model->getuseraddrscheck($userid);
    
    
      		$result=array(
      			     'tabproducts'=>$this->checkout_model->get_categories(),
                 'cartitems'=>$getcartitems,
                 'useradrs'=>$getuseraddrs,
                 'coupon'=>$coupon,
                 'copncamnt'=>$couponcartamnt,
                 'content' => 'checkout'  
                  );
      		
      		    $this->response([
                'data' => $result
            ], REST_Controller::HTTP_OK);
          }
        }
        else
        {
            $this->response([
                'message' => 'Please login',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }  
    }
    

}