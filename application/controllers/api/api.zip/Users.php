<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
use \Firebase\JWT\JWT;

class Users extends MY_Controller {

    public function __construct() { 

        parent::__construct();
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        
        // Load the user model
        $this->load->model('api/user_model','user_model');
        $this->load->model('api/m_main','M_main');
    }
    
    public function login_post() {

        $u = $this->post('username'); //Username Posted
        $p = base64_encode($this->post('password')); //Pasword Posted
        $q = array('user_mail' => $u); //For where query condition
        $kunci = $this->config->item('thekey');
        $invalidLogin = ['status' => 'Invalid Login']; //Respon if login invalid
        $val = $this->M_main->get_user($q)->row(); //Model to get single data row from database base on username

        // print_r($val);
        // exit;

        if($this->M_main->get_user($q)->num_rows() == 0)
        {
            $this->response($invalidLogin, REST_Controller::HTTP_NOT_FOUND);
        }
        $match = $val->user_password;   //Get password for user from database
        

        if($p == $match){ 

            // echo "hello";
            // exit;
            
            //Condition if password matched
        	$token['id'] = $val->user_id;  //From here
            $token['username'] = $u;
            $date = new DateTime();
            $token['iat'] = $date->getTimestamp();
            $token['exp'] = $date->getTimestamp() + 60*60*5; //To here is to generate token
            $output['token'] = JWT::encode($token,$kunci ); //This is the output token

            $userlogindata = array(
                'username' => $val->user_fname,
             'usermail'  => $val->user_mail,
             'usermobile' => $val->user_mobile,
             );


         //   $this->set_response($output, REST_Controller::HTTP_OK); //This is the respon if success

            $this->response(['message' => 'User login successful.',
            'token' => $output['token'],
            'data' => $userlogindata
        ],

            REST_Controller::HTTP_OK);

        }
        else {
            $this->set_response($invalidLogin, REST_Controller::HTTP_NOT_FOUND); //This is the respon if failed
        }


       
    }
    
    public function emailverify_post() {


        $umailid = $this->input->post('mailid');

    	$getsameusercount = $this->user_model->getsameusercount($umailid);

    	if($getsameusercount==0)
    	{

           $datapas = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
           $pass = substr(str_shuffle($datapas), 0, 8);

           $userpassword=base64_encode($pass);

           $insdate = date('Y-m-d');

           $data=array
           (
           	'user_mail'=>$umailid,
           	'user_password'=>$userpassword,
           	'user_status'=>1,
           	'user_date'=>$insdate
           );

           $res = $this->user_model->insertuser($data);

           if($res==1)
           {
           	// echo "success";

            $data2=array
            (
              'username'=>$umailid,
              'password'=>$pass,
              'tomail'=>$umailid,
              'name'=>'User'
            ); 

                    require 'PHPMailer-master/src/Exception.php';
                    require 'PHPMailer-master/src/PHPMailer.php';
                    require 'PHPMailer-master/src/SMTP.php';
                    
                    // $mail = new PHPMailer();
                    $mail=new PHPMailer\PHPMailer\PHPMailer();
                    $mail->IsSMTP();
                    
                    $mail->SMTPDebug  = 0;  
                    $mail->SMTPAuth   = TRUE;
                    $mail->SMTPSecure = "tls";
                    $mail->Port       = 587;
                    $mail->Host       = "smtp.gmail.com";
                    $mail->Username   = "infotootq8@gmail.com";

                    $mail->Password   = "toot@123";
                    
                    $mail->IsHTML(true);
                    $mail->AddAddress($umailid, "User");
                    $mail->SetFrom("infotootq8@gmail.com", "tootq8");
                    $mail->AddReplyTo("infotootq8@gmail.com", "tootq8");
                    //   $mail->AddCC("cc-recipient-email", "cc-recipient-name");
                    $mail->Subject = "TooT Registration confirmattion";
                    $content = $this->load->view('register_mail_view',$data2,TRUE);
                    
                    $mail->MsgHTML($content); 
                    if(!$mail->Send()) {
                        $this->response([
                            'message' => 'Mail Failed'
                        ], REST_Controller::HTTP_BAD_REQUEST);
                       }
                     else {
                       // Set the response and exit
                       $this->response([
                        'message' => 'The mail has been send successfully',
                    ], REST_Controller::HTTP_OK);
                    
                    }


           }
           else
           {
           
            $this->response([
                'message' => 'Failed'
            ], REST_Controller::HTTP_BAD_REQUEST);
            
           }
        }
    	else
    	{
            $this->response([
                'message' => 'User exists'
            ], REST_Controller::HTTP_BAD_REQUEST);
    	}


    }



    public function register_user()
    {
        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $mobile = $this->input->post('mobile');
    	$umailid = $this->input->post('mailid');

    	$getsameusercount = $this->user_model->getsameusercount($umailid);

    	if($getsameusercount==0)
    	{

           $datapas = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
           $pass = substr(str_shuffle($datapas), 0, 8);

           $userpassword=base64_encode($pass);

           $insdate = date('Y-m-d');

           $data=array
           (
           	'user_mail'=>$umailid,
           	'user_password'=>$userpassword,
           	'user_status'=>1,
           	'user_date'=>$insdate
           );

           $res = $this->user_model->insertuser($data);

           if($res==1)
           {
           	// echo "success";

            $data2=array
            (
              'username'=>$umailid,
              'password'=>$pass,
              'tomail'=>$umailid,
              'name'=>'User'
            ); 

                    require 'PHPMailer-master/src/Exception.php';
                    require 'PHPMailer-master/src/PHPMailer.php';
                    require 'PHPMailer-master/src/SMTP.php';
                    
                    // $mail = new PHPMailer();
                    $mail=new PHPMailer\PHPMailer\PHPMailer();
                    $mail->IsSMTP();
                    
                    $mail->SMTPDebug  = 0;  
                    $mail->SMTPAuth   = TRUE;
                    $mail->SMTPSecure = "tls";
                    $mail->Port       = 587;
                    $mail->Host       = "smtp.gmail.com";
                    $mail->Username   = "infotootq8@gmail.com";

                    $mail->Password   = "toot@123";
                    
                    $mail->IsHTML(true);
                    $mail->AddAddress($umailid, "User");
                    $mail->SetFrom("infotootq8@gmail.com", "tootq8");
                    $mail->AddReplyTo("infotootq8@gmail.com", "tootq8");
                    //   $mail->AddCC("cc-recipient-email", "cc-recipient-name");
                    $mail->Subject = "TooT Registration confirmattion";
                    $content = $this->load->view('register_mail_view',$data2,TRUE);
                    
                    $mail->MsgHTML($content); 
                    if(!$mail->Send()) {
                    echo "faild";
                   
                    var_dump($mail);
                    } else {
                        $this->response([
                            'message' => 'Success',
                        ], REST_Controller::HTTP_OK);
                    
                    }


           }
           else
           {
            $this->response([
                'message' => 'Failed'
            ], REST_Controller::HTTP_BAD_REQUEST);
           }
    	}
    	else
    	{
    		$this->response([
                'message' => 'User exists'
            ], REST_Controller::HTTP_BAD_REQUEST);
    	}

    }


    public function logoutuser_get()
    {
    	unset(
	        $_SESSION['userdisplay'],
	        $_SESSION['cusername'],
	        $_SESSION['userid'],
	        $_SESSION['userlogged_in']
	       );
           $this->response([
            'message' => 'Success',
        ], REST_Controller::HTTP_OK);
    }

    

}